extends SceneTree

## TEMP diagnostic: sweeps the pen-web placement and reports, for each candidate,
## the grip geometry AND whether any hand part enters the shaft, so the web is
## chosen from the real convex-shaft test instead of by eye.
##
##   godot --headless --audio-driver Dummy --path . --script tools/debug_web_sweep.gd

const SIDES := 10
const WRIST_OFF := Vector3(0.052, 0.026, 0.104)
const KNUCKLE_DIR := Vector3(-0.42, 0.10, -0.90)
const PALM_LEN := 0.074
const ROLL_DEG := 24.0
const GRIP_HEIGHT := 0.026

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var paper: Node3D = load("res://scenes/telegraph/transcript_paper.tscn").instantiate()
	root.add_child(paper)
	await process_frame
	var to_sheet := paper.global_transform.affine_inverse()
	var nib := paper.get_node("WriterRig/Sleeve/Wrist/Hand/Pen/Nib") as Node3D
	var old_tip: Vector3 = to_sheet * nib.to_global(Vector3(0, -0.011, 0))
	var nib_tip := Vector3(old_tip.x, 0.0006, old_tip.z)
	var shaft := paper.get_node("WriterRig/Sleeve/Wrist/Hand/Pen/Shaft") as MeshInstance3D
	var hand := paper.get_node("WriterRig/Sleeve/Wrist/Hand") as Node3D
	var pen := paper.get_node("WriterRig/Sleeve/Wrist/Hand/Pen") as Node3D
	var to_hand := hand.global_transform.affine_inverse()
	var shaft_in_hand := to_hand * shaft.global_transform
	var cyl := shaft.mesh as CylinderMesh
	var planes := _convex_planes(shaft.mesh, shaft_in_hand, shaft_in_hand.origin)

	var wrist := nib_tip + WRIST_OFF
	var knuckles := wrist + KNUCKLE_DIR.normalized() * PALM_LEN
	var fwd := (knuckles - wrist).normalized()
	var roll := deg_to_rad(ROLL_DEG)
	var tilt := Vector3(sin(roll), cos(roll), 0.0)
	var back := (tilt - fwd * fwd.dot(tilt)).normalized()
	var thumb_side := back.cross(fwd).normalized()
	if thumb_side.x > 0.0:
		thumb_side = -thumb_side
	var k_index := knuckles + thumb_side * 0.034 + fwd * 0.002 + back * 0.004
	var k_middle := knuckles + thumb_side * 0.011 + fwd * 0.006 + back * 0.004

	print("fwd_off  back_off  side_off | elev | wrist->grip | index_pen  thumb_pen  palm_clr")
	for fo in [0.012, 0.018, 0.024, 0.030]:
		for bo in [0.008, 0.016, 0.024]:
			for so in [0.016, 0.020, 0.026]:
				var web := k_index - fwd * fo + back * bo + thumb_side * so
				var a := (web - nib_tip).normalized()
				var grip := nib_tip + a * GRIP_HEIGHT
				var pen_up := (Vector3.UP - a * a.dot(Vector3.UP)).normalized()
				var pen_left := a.cross(pen_up).normalized()
				if pen_left.x > 0.0:
					pen_left = -pen_left
				# Approximate the mesh: only the tubes' centrelines with radii.
				var pts := []
				pts.append(["palm", _tube([wrist + Vector3(0, 0, 0.024), knuckles], 0.036, fwd), 0.036])
				pts.append(["index", _tube([k_index, k_index.lerp(grip + a * 0.013 + pen_up * 0.0115, 0.5), grip + a * 0.013 + pen_up * 0.0115], 0.0088, fwd), 0.0088])
				pts.append(["middle", _tube([k_middle, k_middle.lerp(grip - a * 0.002 + (-pen_up * 0.72 - pen_left * 0.78).normalized() * 0.0112, 0.5), grip - a * 0.002 + (-pen_up * 0.72 - pen_left * 0.78).normalized() * 0.0112], 0.0088, fwd), 0.0088])
				var cmc := wrist + fwd * 0.030 + thumb_side * 0.026 + back * 0.004
				var t_mcp := cmc + (thumb_side * 0.45 + fwd * 0.70 + back * 0.45).normalized() * 0.036
				var t_ip := t_mcp + (fwd * 0.42 + pen_left * 0.52 + a * 0.40).normalized() * 0.024
				var t_tip := grip + a * 0.004 + pen_left * 0.0125
				pts.append(["thumb", _tube([cmc, t_mcp, t_ip, t_tip], 0.0122, thumb_side), 0.0122])
				var pen := {}
				for p in pts:
					var worst := INF
					for c in p[1]:
						var signed := _signed_distance(_hand_inv_sheet(c, paper, hand), planes)
						worst = minf(worst, signed)
					pen[p[0]] = worst - float(p[2])
				print("%7.0f %8.0f %9.0f | %4.1f | %11.1f | %8.2f %9.2f %9.2f" % [
					fo * 1000.0, bo * 1000.0, so * 1000.0, rad_to_deg(asin(a.y)),
					wrist.distance_to(grip) * 1000.0, pen["index"] * 1000.0, pen["thumb"] * 1000.0, pen["palm"] * 1000.0])
	paper.queue_free()
	await process_frame
	quit(0)

func _hand_inv_sheet(p: Vector3, paper: Node3D, hand: Node3D) -> Vector3:
	return hand.global_transform.affine_inverse() * (paper.global_transform * p)

func _tube(centres: Array, r: float, _hint: Vector3) -> Array:
	# Sample the centreline finely; the tube surface is within r of it.
	var out := []
	for i in centres.size() - 1:
		var a: Vector3 = centres[i]
		var b: Vector3 = centres[i + 1]
		for s in 9:
			out.append(a.lerp(b, float(s) / 8.0))
	return out

func _convex_planes(mesh: Mesh, xform: Transform3D, inside_ref: Vector3) -> Array:
	var arrays := mesh.surface_get_arrays(0)
	var verts := arrays[Mesh.ARRAY_VERTEX] as PackedVector3Array
	var index_value: Variant = arrays[Mesh.ARRAY_INDEX]
	var indices: PackedInt32Array = index_value if index_value != null else PackedInt32Array()
	var tri_count := (verts.size() / 3) if indices.is_empty() else (indices.size() / 3)
	var planes: Array = []
	for t in tri_count:
		var i0: int = t * 3 if indices.is_empty() else indices[t * 3]
		var i1: int = t * 3 + 1 if indices.is_empty() else indices[t * 3 + 1]
		var i2: int = t * 3 + 2 if indices.is_empty() else indices[t * 3 + 2]
		var a := xform * verts[i0]
		var b := xform * verts[i1]
		var c := xform * verts[i2]
		var normal := (b - a).cross(c - a).normalized()
		if normal.dot(inside_ref - a) > 0.0:
			normal = -normal
		planes.append(Plane(normal, a))
	return planes

func _signed_distance(point: Vector3, planes: Array) -> float:
	var signed := -INF
	for plane in planes:
		signed = maxf(signed, plane.distance_to(point))
	return signed
