extends SceneTree

## TEMP: per-surface grip-band contacts and nearest signed distance, to see why
## the tripod test reads zero.

const GRIP_BELOW_PEN := -0.043
const GRIP_HALF_BAND := 0.020
const CONTACT_TOLERANCE := 0.0025
const NAMES := ["palm", "index", "middle", "ring", "little", "thumb"]

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var paper: Node3D = load("res://scenes/telegraph/transcript_paper.tscn").instantiate()
	root.add_child(paper)
	await process_frame
	var hand := paper.get_node("WriterRig/Sleeve/Wrist/Hand") as Node3D
	var pen := paper.get_node("WriterRig/Sleeve/Wrist/Hand/Pen") as Node3D
	var shaft := pen.get_node("Shaft") as MeshInstance3D
	var to_hand := hand.global_transform.affine_inverse()
	var shaft_in_hand := to_hand * shaft.global_transform
	var axis := shaft_in_hand.basis.y.normalized()
	var axis_origin := shaft_in_hand.origin
	var planes := _convex_planes(shaft.mesh, shaft_in_hand, axis_origin)
	var pen_along: float = ((to_hand * pen.global_transform).origin - axis_origin).dot(axis)
	var grip_along := pen_along + GRIP_BELOW_PEN
	print("pen_along=%.4f grip_along=%.4f band=[%.4f, %.4f]" % [pen_along, grip_along, grip_along - GRIP_HALF_BAND, grip_along + GRIP_HALF_BAND])
	var hand_mesh := (paper.get_node("WriterRig/Sleeve/Wrist/Hand/HandMesh") as MeshInstance3D).mesh as ArrayMesh
	for s in hand_mesh.get_surface_count():
		var arrays := hand_mesh.surface_get_arrays(s)
		var verts := arrays[Mesh.ARRAY_VERTEX] as PackedVector3Array
		var in_band := 0
		var contacts := 0
		var nearest := INF
		var nearest_at := 0.0
		var nearest_rad := 0.0
		for v in verts:
			var rel: Vector3 = v - axis_origin
			var along: float = rel.dot(axis)
			if along >= grip_along - GRIP_HALF_BAND and along <= grip_along + GRIP_HALF_BAND:
				in_band += 1
				var sd := _signed_distance(v, planes)
				if sd < nearest:
					nearest = sd
					nearest_at = along
					nearest_rad = (rel - axis * along).length()
				if sd <= CONTACT_TOLERANCE:
					contacts += 1
		print("  %-7s in_band=%4d contacts=%4d nearest=%s at along=%+.4f radial=%.4f" % [
			NAMES[s] if s < NAMES.size() else str(s), in_band, contacts,
			("none" if nearest == INF else "%+0.3f mm" % (nearest * 1000.0)), nearest_at, nearest_rad])
	paper.queue_free()
	await process_frame
	quit(0)

func _convex_planes(mesh: Mesh, xform: Transform3D, inside_ref: Vector3) -> Array:
	var arrays := mesh.surface_get_arrays(0)
	var verts := arrays[Mesh.ARRAY_VERTEX] as PackedVector3Array
	var index_value: Variant = arrays[Mesh.ARRAY_INDEX]
	var indices: PackedInt32Array = index_value if index_value != null else PackedInt32Array()
	var tri_count := (verts.size() / 3) if indices.is_empty() else (indices.size() / 3)
	var planes: Array = []
	for t in tri_count:
		var i0: int = t * 3 if indices.is_empty() else indices[t * 3]
		var i1: int = t * 3 + 1 if indices.is_empty() else indices[t * 3 + 1]
		var i2: int = t * 3 + 2 if indices.is_empty() else indices[t * 3 + 2]
		var a := xform * verts[i0]
		var b := xform * verts[i1]
		var c := xform * verts[i2]
		var normal := (b - a).cross(c - a).normalized()
		if normal.dot(inside_ref - a) > 0.0:
			normal = -normal
		planes.append(Plane(normal, a))
	return planes

func _signed_distance(point: Vector3, planes: Array) -> float:
	var signed := -INF
	for plane in planes:
		signed = maxf(signed, plane.distance_to(point))
	return signed
