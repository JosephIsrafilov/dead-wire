extends SceneTree

## TEMP diagnostic: measures the current writing-hand mesh so anatomy defects are
## numbers, not adjectives. Weld-then-union-find groups the loft's rings into
## connected shells; reports each shell's size and the min surface gap between
## every pair (0 = touching/interpenetrating).
##
##   godot --headless --audio-driver Dummy --path . --script tools/debug_hand_anatomy.gd

const WELD := 0.00002

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var paper: Node3D = load("res://scenes/telegraph/transcript_paper.tscn").instantiate()
	root.add_child(paper)
	paper_node = paper
	await process_frame
	_report("HAND", "WriterRig/Sleeve/Wrist/Hand/HandMesh")
	_report("CUFF", "WriterRig/Sleeve/Wrist/WristMesh")
	paper.queue_free()
	await process_frame
	quit(0)

func _report(label: String, path: String) -> void:
	var mi := paper_node.get_node(path) as MeshInstance3D
	if mi == null:
		mi = root.get_node(path) as MeshInstance3D
	if mi == null:
		print("MISSING ", path)
		return
	var arrays := mi.mesh.surface_get_arrays(0)
	var verts := arrays[Mesh.ARRAY_VERTEX] as PackedVector3Array
	var shells := _shells(verts)
	print("=== %s : %d verts, %d shells ===" % [label, verts.size(), shells.size()])
	var centres := []
	for i in shells.size():
		var box := _aabb(shells[i])
		centres.append(box.get_center())
		print("  shell[%d] n=%-4d  size %5.1f x %5.1f x %5.1f mm   centre (%6.1f, %6.1f, %6.1f)" % [
			i, shells[i].size(),
			box.size.x * 1000.0, box.size.y * 1000.0, box.size.z * 1000.0,
			box.get_center().x * 1000.0, box.get_center().y * 1000.0, box.get_center().z * 1000.0])
	print("  gaps (mm), '.' = same pair:")
	for a in shells.size():
		var parts := PackedStringArray()
		for b in shells.size():
			if b <= a:
				parts.append("     .")
			else:
				parts.append("%6.2f" % (_min_gap(shells[a], shells[b]) * 1000.0))
		print("   [%2d] %s" % [a, " ".join(parts)])

func _shells(verts: PackedVector3Array) -> Array:
	var reps := {}
	var index_of := PackedInt32Array()
	index_of.resize(verts.size())
	for i in verts.size():
		var key := "%d|%d|%d" % [
			roundi(verts[i].x / WELD), roundi(verts[i].y / WELD), roundi(verts[i].z / WELD)]
		if reps.has(key):
			index_of[i] = reps[key]
		else:
			reps[key] = i
			index_of[i] = i
	var parent := PackedInt32Array()
	parent.resize(verts.size())
	for i in verts.size():
		parent[i] = i
	for i in verts.size():
		_union(parent, i, index_of[i])
	# Triangles reconnect vertices that the loft duplicated at the same spot.
	var count := verts.size() / 3
	for t in count:
		_union(parent, t * 3, t * 3 + 1)
		_union(parent, t * 3, t * 3 + 2)
	var groups := {}
	for i in verts.size():
		var r := _find(parent, i)
		if not groups.has(r):
			groups[r] = []
		groups[r].append(verts[i])
	var out := []
	for r in groups:
		out.append(groups[r])
	out.sort_custom(func(x, y): return x.size() > y.size())
	return out

func _find(parent: PackedInt32Array, i: int) -> int:
	while parent[i] != i:
		parent[i] = parent[parent[i]]
		i = parent[i]
	return i

func _union(parent: PackedInt32Array, a: int, b: int) -> void:
	var ra := _find(parent, a)
	var rb := _find(parent, b)
	if ra != rb:
		parent[rb] = ra

func _aabb(pts: Array) -> AABB:
	var box := AABB(pts[0], Vector3.ZERO)
	for p in pts:
		box = box.expand(p)
	return box

func _min_gap(a: Array, b: Array) -> float:
	var best := INF
	var step_a: int = maxi(1, a.size() / 300)
	var step_b: int = maxi(1, b.size() / 300)
	var i := 0
	while i < a.size():
		var j := 0
		while j < b.size():
			var d: float = (a[i] as Vector3).distance_squared_to(b[j] as Vector3)
			if d < best:
				best = d
			j += step_b
		i += step_a
	return sqrt(best)

var paper_node: Node3D
