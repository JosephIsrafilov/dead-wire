extends SceneTree

## TEMP diagnostic: radius profile of every shell of the writing hand, so caps,
## joint bulges and Catmull-Rom overshoot are measured instead of asserted.
##
##   godot --headless --audio-driver Dummy --path . --script tools/debug_hand_profile.gd

const WELD := 0.00002
const STATIONS := 14

var paper_node: Node3D

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	paper_node = load("res://scenes/telegraph/transcript_paper.tscn").instantiate()
	root.add_child(paper_node)
	await process_frame
	_profile("HAND", "WriterRig/Sleeve/Wrist/Hand/HandMesh")
	paper_node.queue_free()
	await process_frame
	quit(0)

func _profile(label: String, path: String) -> void:
	var mi := paper_node.get_node(path) as MeshInstance3D
	var arrays := mi.mesh.surface_get_arrays(0)
	var verts := arrays[Mesh.ARRAY_VERTEX] as PackedVector3Array
	var shells := _shells(verts)
	print("=== %s : %d shells ===" % [label, shells.size()])
	for i in shells.size():
		_axis_profile(i, shells[i])

func _axis_profile(index: int, pts: Array) -> void:
	# Principal axis = the farthest pair of points.
	var a: Vector3 = pts[0]
	var b: Vector3 = pts[0]
	var best := -1.0
	var step: int = maxi(1, pts.size() / 300)
	var i := 0
	while i < pts.size():
		var j := 0
		while j < pts.size():
			var d: float = (pts[i] as Vector3).distance_squared_to(pts[j] as Vector3)
			if d > best:
				best = d
				a = pts[i]
				b = pts[j]
			j += step
		i += step
	var axis := (b - a).normalized()
	var length := a.distance_to(b)
	var stations := PackedFloat32Array()
	stations.resize(STATIONS)
	var counts := PackedInt32Array()
	counts.resize(STATIONS)
	var along_min := INF
	var along_max := -INF
	for p in pts:
		var s: float = (p - a).dot(axis)
		along_min = minf(along_min, s)
		along_max = maxf(along_max, s)
	for p in pts:
		var s: float = (p - a).dot(axis)
		var bin: int = clampi(int((s - along_min) / maxf(along_max - along_min, 1e-6) * float(STATIONS - 1) + 0.5), 0, STATIONS - 1)
		var radial: float = ((p - a) - axis * s).length()
		stations[bin] = maxf(stations[bin], radial)
		counts[bin] += 1
	var profile := PackedStringArray()
	for k in STATIONS:
		profile.append("%.1f" % (stations[k] * 1000.0))
	print("  shell[%2d] len=%5.1f mm  maxR=%5.1f mm  radii at %d stations (mm):" % [
		index, length * 1000.0, _maxf(stations) * 1000.0, STATIONS])
	print("      %s" % " ".join(profile))

func _maxf(values: PackedFloat32Array) -> float:
	var m := 0.0
	for v in values:
		m = maxf(m, v)
	return m

func _shells(verts: PackedVector3Array) -> Array:
	var reps := {}
	var index_of := PackedInt32Array()
	index_of.resize(verts.size())
	for i in verts.size():
		var key := "%d|%d|%d" % [
			roundi(verts[i].x / WELD), roundi(verts[i].y / WELD), roundi(verts[i].z / WELD)]
		if reps.has(key):
			index_of[i] = reps[key]
		else:
			reps[key] = i
			index_of[i] = i
	var parent := PackedInt32Array()
	parent.resize(verts.size())
	for i in verts.size():
		parent[i] = i
	for i in verts.size():
		_union(parent, i, index_of[i])
	var count := verts.size() / 3
	for t in count:
		_union(parent, t * 3, t * 3 + 1)
		_union(parent, t * 3, t * 3 + 2)
	var groups := {}
	for i in verts.size():
		var r := _find(parent, i)
		if not groups.has(r):
			groups[r] = []
		groups[r].append(verts[i])
	var out := []
	for r in groups:
		out.append(groups[r])
	out.sort_custom(func(x, y): return x.size() > y.size())
	return out

func _find(parent: PackedInt32Array, i: int) -> int:
	while parent[i] != i:
		parent[i] = parent[parent[i]]
		i = parent[i]
	return i

func _union(parent: PackedInt32Array, a: int, b: int) -> void:
	var ra := _find(parent, a)
	var rb := _find(parent, b)
	if ra != rb:
		parent[rb] = ra
