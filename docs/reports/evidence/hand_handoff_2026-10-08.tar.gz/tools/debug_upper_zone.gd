extends SceneTree

## TEMP diagnostic: names the part that comes closest to the pen shaft in the
## "shaft must run clear above the fingers" band, so the fix is targeted.
##
##   godot --headless --audio-driver Dummy --path . --script tools/debug_upper_zone.gd

const GRIP_BELOW_PEN := -0.043
const UPPER_START_PAST_GRIP := 0.028
const UPPER_END := 0.105
const NAMES := ["palm", "index", "middle", "ring", "little", "thumb"]

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var paper: Node3D = load("res://scenes/telegraph/transcript_paper.tscn").instantiate()
	root.add_child(paper)
	await process_frame
	var hand := paper.get_node("WriterRig/Sleeve/Wrist/Hand") as Node3D
	var pen := paper.get_node("WriterRig/Sleeve/Wrist/Hand/Pen") as Node3D
	var shaft := pen.get_node("Shaft") as MeshInstance3D
	var cyl := shaft.mesh as CylinderMesh
	var to_hand := hand.global_transform.affine_inverse()
	var shaft_in_hand := to_hand * shaft.global_transform
	var axis := shaft_in_hand.basis.y.normalized()
	var axis_origin := shaft_in_hand.origin
	var planes := _convex_planes(shaft.mesh, shaft_in_hand, axis_origin)
	var pen_along: float = ((to_hand * pen.global_transform).origin - axis_origin).dot(axis)
	var grip_along := pen_along + GRIP_BELOW_PEN
	var hand_mesh := (paper.get_node("WriterRig/Sleeve/Wrist/Hand/HandMesh") as MeshInstance3D).mesh as ArrayMesh
	print("surfaces = ", hand_mesh.get_surface_count())
	for s in hand_mesh.get_surface_count():
		var arrays := hand_mesh.surface_get_arrays(s)
		var verts := arrays[Mesh.ARRAY_VERTEX] as PackedVector3Array
		var best := INF
		var worst_pen := 0.0
		var n := 0
		for v in verts:
			var signed := _signed_distance(v, planes)
			if signed < 0.0:
				worst_pen = maxf(worst_pen, -signed)
			var along: float = (v - axis_origin).dot(axis)
			if along > grip_along + UPPER_START_PAST_GRIP and along <= UPPER_END:
				n += 1
				best = minf(best, signed)
		print("  %-7s verts=%4d  in upper band=%3d  min clearance=%s  worst penetration=%.2f mm" % [
			NAMES[s] if s < NAMES.size() else str(s), verts.size(), n,
			("none" if best == INF else "%.2f mm" % (best * 1000.0)), worst_pen * 1000.0])
	paper.queue_free()
	await process_frame
	quit(0)

func _convex_planes(mesh: Mesh, xform: Transform3D, inside_ref: Vector3) -> Array:
	var arrays := mesh.surface_get_arrays(0)
	var verts := arrays[Mesh.ARRAY_VERTEX] as PackedVector3Array
	var index_value: Variant = arrays[Mesh.ARRAY_INDEX]
	var indices: PackedInt32Array = index_value if index_value != null else PackedInt32Array()
	var tri_count := (verts.size() / 3) if indices.is_empty() else (indices.size() / 3)
	var planes: Array = []
	for t in tri_count:
		var i0: int = t * 3 if indices.is_empty() else indices[t * 3]
		var i1: int = t * 3 + 1 if indices.is_empty() else indices[t * 3 + 1]
		var i2: int = t * 3 + 2 if indices.is_empty() else indices[t * 3 + 2]
		var a := xform * verts[i0]
		var b := xform * verts[i1]
		var c := xform * verts[i2]
		var normal := (b - a).cross(c - a).normalized()
		if normal.dot(inside_ref - a) > 0.0:
			normal = -normal
		planes.append(Plane(normal, a))
	return planes

func _signed_distance(point: Vector3, planes: Array) -> float:
	var signed := -INF
	for plane in planes:
		signed = maxf(signed, plane.distance_to(point))
	return signed
