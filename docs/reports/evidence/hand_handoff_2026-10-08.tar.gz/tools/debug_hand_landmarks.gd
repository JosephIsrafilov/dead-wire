extends SceneTree

## TEMP diagnostic: replicates the generator's sheet-space joint maths and prints
## every landmark + segment length, so proportions can be judged against an adult
## right hand instead of against the render.
##
##   godot --headless --audio-driver Dummy --path . --script tools/debug_hand_landmarks.gd

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var paper: Node3D = load("res://scenes/telegraph/transcript_paper.tscn").instantiate()
	root.add_child(paper)
	await process_frame
	var to_sheet := paper.global_transform.affine_inverse()
	var nib := paper.get_node("WriterRig/Sleeve/Wrist/Hand/Pen/Nib") as Node3D

	var old_tip: Vector3 = to_sheet * nib.to_global(Vector3(0, -0.011, 0))
	var nib_tip := Vector3(old_tip.x, 0.0006, old_tip.z)
	var wrist := nib_tip + Vector3(0.088, 0.028, 0.142)
	var knuckles := nib_tip + Vector3(0.050, 0.040, 0.052)
	var fwd := (knuckles - wrist).normalized()
	var roll := deg_to_rad(24.0)
	var tilt := Vector3(sin(roll), cos(roll), 0.0)
	var back := (tilt - fwd * fwd.dot(tilt)).normalized()
	var thumb_side := back.cross(fwd).normalized()
	if thumb_side.x > 0.0:
		thumb_side = -thumb_side
	var k_index := knuckles + thumb_side * 0.030 + fwd * 0.002 + back * 0.004
	var web := k_index - fwd * 0.024 + back * 0.016 + thumb_side * 0.020
	var a := (web - nib_tip).normalized()
	var grip := nib_tip + a * 0.026
	var pen_up := (Vector3.UP - a * a.dot(Vector3.UP)).normalized()
	var pen_left := a.cross(pen_up).normalized()
	if pen_left.x > 0.0:
		pen_left = -pen_left
	var k_middle := knuckles + thumb_side * 0.010 + fwd * 0.006 + back * 0.004
	var k_ring := knuckles - thumb_side * 0.011 + fwd * 0.003 + back * 0.003
	var k_little := knuckles - thumb_side * 0.029 - fwd * 0.006 + back * 0.002
	var i_tip := grip + a * 0.013 + pen_up * 0.0127
	var m_tip := grip - a * 0.002 + (-pen_up * 0.72 - pen_left * 0.78).normalized() * 0.0126
	var t_base := wrist + thumb_side * 0.022 + fwd * 0.012 - back * 0.004
	var t_tip := grip + a * 0.004 + pen_left * 0.0137
	var t_mcp := t_base.lerp(t_tip, 0.45) + thumb_side * 0.012 - back * 0.004
	var t_ip := t_base.lerp(t_tip, 0.78) + thumb_side * 0.005

	print("NIB tip    ", _mm(nib_tip))
	print("WRIST      ", _mm(wrist))
	print("KNUCKLES   ", _mm(knuckles))
	print("GRIP       ", _mm(grip))
	print("--- lengths ---")
	print("wrist->knuckles (hand)      %6.1f mm" % (wrist.distance_to(knuckles) * 1000.0))
	print("nib->grip (pen grip height) %6.1f mm" % (nib_tip.distance_to(grip) * 1000.0))
	print("wrist->grip                 %6.1f mm" % (wrist.distance_to(grip) * 1000.0))
	print("--- index chain ---")
	print("  k_index->i_tip  %6.1f mm" % (k_index.distance_to(i_tip) * 1000.0))
	print("--- middle chain ---")
	print("  k_middle->m_tip %6.1f mm" % (k_middle.distance_to(m_tip) * 1000.0))
	print("--- thumb chain (base at WRIST?) ---")
	print("  t_base->t_tip   %6.1f mm" % (t_base.distance_to(t_tip) * 1000.0))
	print("  t_base->t_mcp   %6.1f mm" % (t_base.distance_to(t_mcp) * 1000.0))
	print("  t_mcp->t_ip     %6.1f mm" % (t_mcp.distance_to(t_ip) * 1000.0))
	print("  t_ip->t_tip     %6.1f mm" % (t_ip.distance_to(t_tip) * 1000.0))
	print("  t_base to knuckles %6.1f mm" % (t_base.distance_to(knuckles) * 1000.0))
	print("--- ring/little (tucked) ---")
	for k in [k_ring, k_little]:
		var r0: float = 0.0082 if k == k_ring else 0.0070
		var pip: Vector3 = k + fwd * 0.026
		pip.y = r0 * 0.95
		var dip: Vector3 = k + fwd * 0.014
		dip.y = r0 * 0.72
		var tip: Vector3 = k + fwd * 0.009
		tip.y = r0 * 0.58
		print("  k=%s pip=%s dip=%s tip=%s  reach=%.1f mm" % [
			_mm(k), _mm(pip), _mm(dip), _mm(tip), k.distance_to(tip) * 1000.0])
	print("--- knuckle ridge spread ---")
	print("  k_index->k_little %6.1f mm" % (k_index.distance_to(k_little) * 1000.0))
	print("  k_index->k_middle %6.1f mm" % (k_index.distance_to(k_middle) * 1000.0))
	print("  k_middle->k_ring  %6.1f mm" % (k_middle.distance_to(k_ring) * 1000.0))
	print("  k_ring->k_little  %6.1f mm" % (k_ring.distance_to(k_little) * 1000.0))
	print("--- pen axis elevation ---")
	print("  a elevation %.1f deg" % rad_to_deg(asin(a.y)))
	paper.queue_free()
	await process_frame
	quit(0)

func _mm(v: Vector3) -> String:
	return "(%6.1f, %6.1f, %6.1f) mm" % [v.x * 1000.0, v.y * 1000.0, v.z * 1000.0]
