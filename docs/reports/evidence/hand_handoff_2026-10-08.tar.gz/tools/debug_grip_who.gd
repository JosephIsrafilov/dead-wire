extends SceneTree

## Prints the positions + colours of vertices still inside the shaft.
func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var paper := (load("res://scenes/telegraph/transcript_paper.tscn") as PackedScene).instantiate()
	root.add_child(paper)
	await process_frame
	var hand := paper.get_node("WriterRig/Sleeve/Wrist/Hand") as Node3D
	var pen := paper.get_node("WriterRig/Sleeve/Wrist/Hand/Pen") as Node3D
	var to_hand: Transform3D = hand.global_transform.affine_inverse()
	var pen_in_hand := to_hand * pen.global_transform
	var axis_dir := pen_in_hand.basis.y.normalized()
	var axis_origin := pen_in_hand.origin
	var hand_mesh := paper.get_node("WriterRig/Sleeve/Wrist/Hand/HandMesh") as MeshInstance3D
	var arrays := hand_mesh.mesh.surface_get_arrays(0)
	var verts: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
	var cols: PackedColorArray = arrays[Mesh.ARRAY_COLOR]
	for i in verts.size():
		var rel := verts[i] - axis_origin
		var along: float = rel.dot(axis_dir)
		var radial: float = (rel - axis_dir * along).length()
		if radial < 0.0042 and along >= -0.055 and along <= 0.105:
			print("v along=%+5.1fmm radial=%.2fmm col=%s local=%s" % [along * 1000, radial * 1000, cols[i], verts[i]])
	quit(0)
