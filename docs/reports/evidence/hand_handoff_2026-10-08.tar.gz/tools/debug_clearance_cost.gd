extends SceneTree

## TEMP: closed-annotation probe — for each hand-vertex surface, how much of
## the saved mesh still sits inside the real Pen shaft? Treats each hex cell
## as a closed convex: a vertex inside the cell is " внутри". The existing
## writer_hand_test asserts zero penetration, so this is expected to be zero
## after `_clear_point`/`_clamp_vertex`; we want to know the COST — how many
## vertices were shoved.
##
##   godot --headless --audio-driver Dummy --path . --script tools/debug_clearance_cost.gd

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var paper: Node3D = load("res://scenes/telegraph/transcript_paper.tscn").instantiate()
	root.add_child(paper)
	await process_frame
	var hand := paper.get_node("WriterRig/Sleeve/Wrist/Hand") as Node3D
	var shaft := paper.get_node("WriterRig/Sleeve/Wrist/Hand/Pen/Shaft") as MeshInstance3D
	var cyl := shaft.mesh as CylinderMesh
	var to_hand := hand.global_transform.affine_inverse()
	var shaft_in := to_hand * shaft.global_transform
	var axis := shaft_in.basis.y.normalized()
	var half := cyl.height * 0.5
	var r_bot := cyl.bottom_radius
	var r_top := cyl.top_radius
	var mesh := paper.get_node("WriterRig/Sleeve/Wrist/Hand/HandMesh") as MeshInstance3D
	var part_names := ["palm", "index", "middle", "ring", "little", "thumb"]
	var counts := {}
	var worst := 0.0
	for s in (mesh.mesh as ArrayMesh).get_surface_count():
		var part: String = part_names[s]
		var arr := (mesh.mesh.surface_get_arrays(s) as Array)[Mesh.ARRAY_VERTEX] as PackedVector3Array
		var moved := 0
		for v in arr:
			var along := (v - shaft_in.origin).dot(axis)
			if along < -half or along > half:
				continue
			var t := clampf((along + half) / (half * 2.0), 0.0, 1.0)
			var r := lerpf(r_bot, r_top, t)
			var planar: Vector3 = v - shaft_in.origin - axis * along
			var d := planar.length()
			if d < r - 0.0002:
				moved += 1
				worst = maxf(worst, r - d)
		counts[part] = { "inside": moved, "vs_total": arr.size() }
	print("=== still inside shaft after guard ===")
	for p in part_names:
		var c: Dictionary = counts[p]
		print("  %-7s %d of %d vertices" % [p, c["inside"], c["vs_total"]])
	print("  worst inward penetration: %.2f mm" % (worst * 1000.0))
	paper.queue_free()
	await process_frame
	quit(0)
