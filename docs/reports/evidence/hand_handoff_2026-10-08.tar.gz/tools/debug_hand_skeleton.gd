extends SceneTree

## TEMP: prints the writing hand's authored skeleton as numbers, in sheet
## space, so proportions can be compared against anthropometric ranges
## instead of guessed from a render.
##
##   godot --headless --audio-driver Dummy --path . --script tools/debug_hand_skeleton.gd

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var paper: Node3D = load("res://scenes/telegraph/transcript_paper.tscn").instantiate()
	root.add_child(paper)
	await process_frame
	var to_sheet := paper.global_transform.affine_inverse()
	var nib := paper.get_node("WriterRig/Sleeve/Wrist/Hand/Pen/Nib") as Node3D
	var shaft := paper.get_node("WriterRig/Sleeve/Wrist/Hand/Pen/Shaft") as MeshInstance3D
	var cyl := shaft.mesh as CylinderMesh
	var axis_origin: Vector3 = to_sheet * shaft.global_position
	var axis_dir: Vector3 = (to_sheet.basis * shaft.global_transform.basis.y).normalized()
	var nib_tip: Vector3 = to_sheet * nib.to_global(Vector3(0, -0.011, 0))
	nib_tip.y = 0.0006
	var pen_node := paper.get_node("WriterRig/Sleeve/Wrist/Hand/Pen") as Node3D
	var pen_along: float = ((to_sheet * pen_node.global_position) - axis_origin).dot(axis_dir)
	var grip_along: float = pen_along - 0.043

	var wrist := nib_tip + Vector3(0.052, 0.026, 0.104)
	var knuckles := wrist + Vector3(-0.42, 0.10, -0.90).normalized() * 0.074
	var fwd := (knuckles - wrist).normalized()
	var roll := deg_to_rad(24.0)
	var tilt := Vector3(sin(roll), cos(roll), 0.0)
	var back := (tilt - fwd * fwd.dot(tilt)).normalized()
	var thumb_side := back.cross(fwd).normalized()
	if thumb_side.x > 0.0:
		thumb_side = -thumb_side
	var k_index := knuckles + thumb_side * 0.034 + fwd * 0.002 + back * 0.004
	var k_middle := knuckles + thumb_side * 0.011 + fwd * 0.006 + back * 0.004
	var k_ring := knuckles - thumb_side * 0.012 + fwd * 0.003 + back * 0.003
	var k_little := knuckles - thumb_side * 0.035 - fwd * 0.006 + back * 0.002
	var web := k_index - fwd * 0.022 + back * 0.026 + thumb_side * 0.024
	var a := (web - nib_tip).normalized()
	var grip := nib_tip + a * 0.026

	print("=== SHEET SPACE (m) ===")
	print("  nib_tip      ", nib_tip)
	print("  shaft origin ", axis_origin, "  dir ", axis_dir)
	print("  grip_along from shaft centre: %.4f  shaft half %.4f" % [grip_along, cyl.height * 0.5])
	print("  wrist        ", wrist)
	print("  knuckles     ", knuckles)
	print("  grip (pen)   ", grip, "   pen dir ", a)
	print("=== LENGTHS (mm) ===")
	var i_tip := _grip_tip(axis_origin, axis_dir, grip_along, cyl, 0.010, Vector3.UP, 0.0012)
	var m_dir := (-Vector3.UP * 0.72 - _left(a) * 0.78).normalized()
	var m_tip := _grip_tip(axis_origin, axis_dir, grip_along, cyl, -0.002, m_dir, 0.0012)
	var t_tip := _grip_tip(axis_origin, axis_dir, grip_along, cyl, 0.002, _left(a), 0.0012)
	_rows([
		["wrist -> knuckles (palm length)", wrist.distance_to(knuckles)],
		["wrist -> grip", wrist.distance_to(grip)],
		["knuckles -> grip", knuckles.distance_to(grip)],
		["index  MCP -> tip", k_index.distance_to(i_tip)],
		["middle MCP -> tip", k_middle.distance_to(m_tip)],
		["thumb  CMC -> tip", wrist.distance_to(t_tip)],
		["palm breadth (index->little MCP)", k_index.distance_to(k_little)],
		["index->middle MCP", k_index.distance_to(k_middle)],
		["middle->ring MCP", k_middle.distance_to(k_ring)],
		["ring->little MCP", k_ring.distance_to(k_little)],
	])
	# Anthropometric reference: adult male, dorsal wrist crease to MCP heads
	# ~100 mm; index MCP->tip ~74, middle ~80, ring ~76, little ~62 mm;
	# hand breadth across MCPs ~88 mm. Moderate confidence (standard tables).
	print("=== REFERENCE (adult male, moderate confidence) ===")
	print("  palm 100 | index 74 | middle 80 | ring 76 | little 62 | breadth 88")
	paper.queue_free()
	await process_frame
	quit(0)

func _left(a: Vector3) -> Vector3:
	var up := (Vector3.UP - a * a.dot(Vector3.UP)).normalized()
	var l := a.cross(up).normalized()
	if l.x > 0.0:
		l = -l
	return l

func _grip_tip(origin: Vector3, dir: Vector3, along: float, cyl: CylinderMesh,
		offset: float, tip_dir: Vector3, gap: float) -> Vector3:
	var al := along + offset
	var t := clampf((al + cyl.height * 0.5) / cyl.height, 0.0, 1.0)
	var r := lerpf(cyl.bottom_radius, cyl.top_radius, t)
	return origin + dir * al + tip_dir.normalized() * (r + gap)

func _rows(rows: Array) -> void:
	for row in rows:
		print("  %-34s %6.1f" % [row[0], (row[1] as float) * 1000.0])
