extends SceneTree

## TEMP diagnostic: quantifies Catmull-Rom overshoot and cap domes on the current
## generator's chains, so "the smoothing bulges" is a measured claim.
##
##   godot --headless --audio-driver Dummy --path . --script tools/debug_hand_overshoot.gd

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var paper: Node3D = load("res://scenes/telegraph/transcript_paper.tscn").instantiate()
	root.add_child(paper)
	await process_frame
	var to_sheet := paper.global_transform.affine_inverse()
	var nib := paper.get_node("WriterRig/Sleeve/Wrist/Hand/Pen/Nib") as Node3D
	var old_tip: Vector3 = to_sheet * nib.to_global(Vector3(0, -0.011, 0))
	var nib_tip := Vector3(old_tip.x, 0.0006, old_tip.z)
	var wrist := nib_tip + Vector3(0.088, 0.028, 0.142)
	var knuckles := nib_tip + Vector3(0.050, 0.040, 0.052)
	var fwd := (knuckles - wrist).normalized()
	var roll := deg_to_rad(24.0)
	var tilt := Vector3(sin(roll), cos(roll), 0.0)
	var back := (tilt - fwd * fwd.dot(tilt)).normalized()
	var thumb_side := back.cross(fwd).normalized()
	if thumb_side.x > 0.0:
		thumb_side = -thumb_side
	var k_index := knuckles + thumb_side * 0.030 + fwd * 0.002 + back * 0.004
	var web := k_index - fwd * 0.024 + back * 0.016 + thumb_side * 0.020
	var a := (web - nib_tip).normalized()
	var grip := nib_tip + a * 0.026
	var pen_up := (Vector3.UP - a * a.dot(Vector3.UP)).normalized()
	var pen_left := a.cross(pen_up).normalized()
	if pen_left.x > 0.0:
		pen_left = -pen_left
	var k_middle := knuckles + thumb_side * 0.010 + fwd * 0.006 + back * 0.004
	var k_ring := knuckles - thumb_side * 0.011 + fwd * 0.003 + back * 0.003
	var k_little := knuckles - thumb_side * 0.029 - fwd * 0.006 + back * 0.002
	var i_tip := grip + a * 0.013 + pen_up * 0.0127
	var m_tip := grip - a * 0.002 + (-pen_up * 0.72 - pen_left * 0.78).normalized() * 0.0126
	var t_base := wrist + thumb_side * 0.022 + fwd * 0.012 - back * 0.004
	var t_tip := grip + a * 0.004 + pen_left * 0.0137
	var t_mcp := t_base.lerp(t_tip, 0.45) + thumb_side * 0.012 - back * 0.004
	var t_ip := t_base.lerp(t_tip, 0.78) + thumb_side * 0.005

	_overshoot("index", [k_index, k_index.lerp(i_tip, 0.40) + back * 0.020, k_index.lerp(i_tip, 0.74) + back * 0.009, i_tip])
	_overshoot("middle", [k_middle, k_middle.lerp(m_tip, 0.40) + back * 0.012, k_middle.lerp(m_tip, 0.74) + back * 0.005, m_tip])
	_overshoot("thumb", [t_base, t_mcp, t_ip, t_tip])
	for k in [k_ring, k_little]:
		var r0: float = 0.0082 if k == k_ring else 0.0070
		var pip: Vector3 = k + fwd * 0.026
		pip.y = r0 * 0.95
		var dip: Vector3 = k + fwd * 0.014
		dip.y = r0 * 0.72
		var tip: Vector3 = k + fwd * 0.009
		tip.y = r0 * 0.58
		_overshoot("tucked(ring/little)", [k, pip, dip, tip])
	_cap_dome("index tip r=7.0mm", 0.0070)
	paper.queue_free()
	await process_frame
	quit(0)

## How far the smoothed path departs from the straight polyline through the
## control points, and the arc/chord ratio. Uniform Catmull-Rom overshoots when
## the knots are unevenly spaced.
func _overshoot(name: String, points: Array) -> void:
	var path := _smooth(points, 4)
	var chord: float = (points[0] as Vector3).distance_to(points[points.size() - 1])
	var arc := 0.0
	for i in path.size() - 1:
		arc += (path[i] as Vector3).distance_to(path[i + 1])
	var max_dev := 0.0
	var at_t := 0.0
	for i in path.size():
		var dev := _dev_from_polyline(path[i], points)
		if dev > max_dev:
			max_dev = dev
			at_t = float(i) / float(path.size() - 1)
	var seg := PackedStringArray()
	for i in points.size() - 1:
		seg.append("%.1f" % ((points[i] as Vector3).distance_to(points[i + 1]) * 1000.0))
	print("%-22s knots %s mm | chord %5.1f arc %5.1f (arc/chord %.2f) | max deviation from control polyline %5.2f mm at t=%.2f" % [
		name, ",".join(seg), chord * 1000.0, arc * 1000.0, arc / maxf(chord, 1e-6), max_dev * 1000.0, at_t])

func _dev_from_polyline(p: Vector3, points: Array) -> float:
	var best := INF
	for i in points.size() - 1:
		best = minf(best, _seg_dist(p, points[i], points[i + 1]))
	return best

func _seg_dist(p: Vector3, a: Vector3, b: Vector3) -> float:
	var ab := b - a
	var t: float = clampf((p - a).dot(ab) / maxf(ab.length_squared(), 1e-12), 0.0, 1.0)
	return p.distance_to(a + ab * t)

func _smooth(points: Array, steps: int) -> Array:
	var out := []
	for i in points.size() - 1:
		var p0: Vector3 = points[maxi(i - 1, 0)]
		var p1: Vector3 = points[i]
		var p2: Vector3 = points[i + 1]
		var p3: Vector3 = points[mini(i + 2, points.size() - 1)]
		for s in steps:
			out.append(p1.cubic_interpolate(p2, p0, p3, float(s) / float(steps)))
	out.append(points[points.size() - 1])
	return out

func _cap_dome(name: String, radius: float) -> void:
	print("%-22s dome apex sits %.2f mm past the end ring (0.55 x r) — a hemisphere, not a fingertip pad" % [
		name, radius * 0.55 * 1000.0])
